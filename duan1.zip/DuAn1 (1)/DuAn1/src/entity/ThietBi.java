/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author DELL
 */
public class ThietBi {

    String MaTB;
    String TenTB;
    String MaNSX;   
    String MaLoai;
    int GiaNiemYet;
    String MaNCC;
    String Hinh;
    int HanBaoHanh;

    public String getMaTB() {
        return MaTB;
    }

    public void setMaTB(String MaTB) {
        this.MaTB = MaTB;
    }

    public String getTenTB() {
        return TenTB;
    }

    public void setTenTB(String TenTB) {
        this.TenTB = TenTB;
    }

    public String getMaNSX() {
        return MaNSX;
    }

    public void setMaNSX(String MaNSX) {
        this.MaNSX = MaNSX;
    }

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String MaLoai) {
        this.MaLoai = MaLoai;
    }

    public int getGiaNiemYet() {
        return GiaNiemYet;
    }

    public void setGiaNiemYet(int GiaNiemYet) {
        this.GiaNiemYet = GiaNiemYet;
    }

    public String getMaNCC() {
        return MaNCC;
    }

    public void setMaNCC(String MaNCC) {
        this.MaNCC = MaNCC;
    }

    public String getHinh() {
        return Hinh;
    }

    public void setHinh(String Hinh) {
        this.Hinh = Hinh;
    }

    public int getHanBaoHanh() {
        return HanBaoHanh;
    }

    public void setHanBaoHanh(int HanBaoHanh) {
        this.HanBaoHanh = HanBaoHanh;
    }

    @Override
    public String toString() {
        return TenTB;
    }

    
    
}
