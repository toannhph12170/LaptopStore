package entity;

public class BaoHanh {

    String MaBH;
    String MaKH;
    String NgayBH;

    public String getMaBH() {
        return MaBH;
    }

    public void setMaBH(String MaBH) {
        this.MaBH = MaBH;
    }

    public String getMaKH() {
        return MaKH;
    }

    public void setMaKH(String MaKH) {
        this.MaKH = MaKH;
    }

    public String getNgayBH() {
        return NgayBH;
    }

    public void setNgayBH(String NgayBH) {
        this.NgayBH = NgayBH;
    }
        
    
}
