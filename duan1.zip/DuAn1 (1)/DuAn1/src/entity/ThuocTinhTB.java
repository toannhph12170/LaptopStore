/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author DELL
 */
public class ThuocTinhTB {

    String MaTB;
    String GiaTri1;
    String GiaTri2;
    String GiaTri3;
    String GiaTri4;
    String GiaTri5;
    String GiaTri6;
    String GiaTri7;
    String GiaTri8;
    String GiaTri9;
    String GiaTri10;

    public String getMaTB() {
        return MaTB;
    }

    public void setMaTB(String MaTB) {
        this.MaTB = MaTB;
    }

    public String getGiaTri1() {
        return GiaTri1;
    }

    public void setGiaTri1(String GiaTri1) {
        this.GiaTri1 = GiaTri1;
    }

    public String getGiaTri2() {
        return GiaTri2;
    }

    public void setGiaTri2(String GiaTri2) {
        this.GiaTri2 = GiaTri2;
    }

    public String getGiaTri3() {
        return GiaTri3;
    }

    public void setGiaTri3(String GiaTri3) {
        this.GiaTri3 = GiaTri3;
    }

    public String getGiaTri4() {
        return GiaTri4;
    }

    public void setGiaTri4(String GiaTri4) {
        this.GiaTri4 = GiaTri4;
    }

    public String getGiaTri5() {
        return GiaTri5;
    }

    public void setGiaTri5(String GiaTri5) {
        this.GiaTri5 = GiaTri5;
    }

    public String getGiaTri6() {
        return GiaTri6;
    }

    public void setGiaTri6(String GiaTri6) {
        this.GiaTri6 = GiaTri6;
    }

    public String getGiaTri7() {
        return GiaTri7;
    }

    public void setGiaTri7(String GiaTri7) {
        this.GiaTri7 = GiaTri7;
    }

    public String getGiaTri8() {
        return GiaTri8;
    }

    public void setGiaTri8(String GiaTri8) {
        this.GiaTri8 = GiaTri8;
    }

    public String getGiaTri9() {
        return GiaTri9;
    }

    public void setGiaTri9(String GiaTri9) {
        this.GiaTri9 = GiaTri9;
    }

    public String getGiaTri10() {
        return GiaTri10;
    }

    public void setGiaTri10(String GiaTri10) {
        this.GiaTri10 = GiaTri10;
    }
    
    
}
