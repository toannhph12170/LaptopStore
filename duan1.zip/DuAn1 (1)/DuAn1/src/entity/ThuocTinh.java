/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author DELL
 */
public class ThuocTinh {

    String MaLoai;
    String ThuocTinh1;
    String ThuocTinh2;
    String ThuocTinh3;
    String ThuocTinh4;
    String ThuocTinh5;
    String ThuocTinh6;
    String ThuocTinh7;
    String ThuocTinh8;
    String ThuocTinh9;
    String ThuocTinh10;

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String MaLoai) {
        this.MaLoai = MaLoai;
    }

    public String getThuocTinh1() {
        return ThuocTinh1;
    }

    public void setThuocTinh1(String ThuocTinh1) {
        this.ThuocTinh1 = ThuocTinh1;
    }

    public String getThuocTinh2() {
        return ThuocTinh2;
    }

    public void setThuocTinh2(String ThuocTinh2) {
        this.ThuocTinh2 = ThuocTinh2;
    }

    public String getThuocTinh3() {
        return ThuocTinh3;
    }

    public void setThuocTinh3(String ThuocTinh3) {
        this.ThuocTinh3 = ThuocTinh3;
    }

    public String getThuocTinh4() {
        return ThuocTinh4;
    }

    public void setThuocTinh4(String ThuocTinh4) {
        this.ThuocTinh4 = ThuocTinh4;
    }

    public String getThuocTinh5() {
        return ThuocTinh5;
    }

    public void setThuocTinh5(String ThuocTinh5) {
        this.ThuocTinh5 = ThuocTinh5;
    }

    public String getThuocTinh6() {
        return ThuocTinh6;
    }

    public void setThuocTinh6(String ThuocTinh6) {
        this.ThuocTinh6 = ThuocTinh6;
    }

    public String getThuocTinh7() {
        return ThuocTinh7;
    }

    public void setThuocTinh7(String ThuocTinh7) {
        this.ThuocTinh7 = ThuocTinh7;
    }

    public String getThuocTinh8() {
        return ThuocTinh8;
    }

    public void setThuocTinh8(String ThuocTinh8) {
        this.ThuocTinh8 = ThuocTinh8;
    }

    public String getThuocTinh9() {
        return ThuocTinh9;
    }

    public void setThuocTinh9(String ThuocTinh9) {
        this.ThuocTinh9 = ThuocTinh9;
    }

    public String getThuocTinh10() {
        return ThuocTinh10;
    }

    public void setThuocTinh10(String ThuocTinh10) {
        this.ThuocTinh10 = ThuocTinh10;
    }

    
    
    
}
