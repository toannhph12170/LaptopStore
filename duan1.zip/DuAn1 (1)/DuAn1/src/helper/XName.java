
package helper;

/**
 *
 * @author DELL
 */
public class XName {
    public static XName name = null;
}
