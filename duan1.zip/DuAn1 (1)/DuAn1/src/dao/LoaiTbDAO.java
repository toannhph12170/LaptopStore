/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.LoaiTB;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class LoaiTbDAO extends DAdao<LoaiTB, String> {

    String INSERT_SQL = "INSERT INTO LoaiTB (MaLoai, TenLoai, DonViTinh, GhiChu) VALUES (?,?,?,?)";
    String UPDATE_SQL = "UPDATE LoaiTB SET TenLoai =?, DonViTinh =?, GhiChu =? WHERE MaLoai = ?";
    String DELETE_SQL = "DELETE FROM LoaiTB WHERE MaLoai = ?";
    String SELECT_ALL = "SELECT * FROM LoaiTB";
    String SELECT_BY_ID = "SELECT * FROM LoaiTB WHERE MaLoai = ?";

    @Override
    public void insert(LoaiTB entity) {
        XJdbc.update(INSERT_SQL, entity.getMaLoai(), entity.getTenLoai(), entity.getDonViTinh(), entity.getGhiChu());
    }

    @Override
    public void update(LoaiTB entity) {
        XJdbc.update(UPDATE_SQL, entity.getTenLoai(), entity.getDonViTinh(), entity.getGhiChu(), entity.getMaLoai());
    }

    @Override
    public void delete(String id) {
        XJdbc.update(DELETE_SQL, id);
    }

    @Override
    public List<LoaiTB> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public LoaiTB selectById(String id) {
        List<LoaiTB> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }
    
    public List<LoaiTB> selectByKeyWord(String keyword){
        String sql = "select * from LoaiTB where TenLoai like ?";
        return this.selectBySql(sql, "%"+keyword+"%");
    }

    @Override
    protected List<LoaiTB> selectBySql(String sql, Object... args) {
        List<LoaiTB> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                LoaiTB entity = new LoaiTB();
                entity.setMaLoai(rs.getString("MaLoai"));
                entity.setTenLoai(rs.getString("TenLoai"));
                entity.setDonViTinh(rs.getString("DonViTinh"));
                entity.setGhiChu(rs.getString("GhiChu"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
