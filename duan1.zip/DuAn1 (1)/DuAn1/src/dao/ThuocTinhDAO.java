/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.ThuocTinh;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class ThuocTinhDAO extends DAdao<ThuocTinh, String>{
    String INSERT_SQL = "INSERT INTO ThuocTinh(Maloai) VALUES (?)";
    String UPDATE_SQL = "UPDATE ThuocTinh SET ThuocTinh1 =?, ThuocTinh2 =?, "
            + "ThuocTinh3 =?, ThuocTinh4 =?, ThuocTinh5 =?," +
"ThuocTinh6 =?, ThuocTinh7 =?, ThuocTinh8 =?, ThuocTinh9 =?, ThuocTinh10 =? WHERE MaLoai =?";
    String SELECT_BY_ID = "SELECT * FROM ThuocTinh WHERE MaLoai = ?";
    @Override
    public void insert(ThuocTinh entity) {
        XJdbc.update(INSERT_SQL, entity.getMaLoai());
    }

    @Override
    public void update(ThuocTinh entity) {
        XJdbc.update(UPDATE_SQL, entity.getThuocTinh1(), entity.getThuocTinh2(), entity.getThuocTinh3(),
                entity.getThuocTinh4(), entity.getThuocTinh5(), entity.getThuocTinh6(), entity.getThuocTinh7(),
                entity.getThuocTinh8(), entity.getThuocTinh9(), entity.getThuocTinh10(), entity.getMaLoai());
    }

    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ThuocTinh> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ThuocTinh selectById(String id) {
        List<ThuocTinh> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<ThuocTinh> selectBySql(String sql, Object... args) {
        List<ThuocTinh> list = new ArrayList<>();
        try {            
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                ThuocTinh entity = new ThuocTinh();
                entity.setMaLoai(rs.getString("MaLoai"));
                entity.setThuocTinh1(rs.getString("ThuocTinh1"));
                entity.setThuocTinh2(rs.getString("ThuocTinh2"));
                entity.setThuocTinh3(rs.getString("ThuocTinh3"));
                entity.setThuocTinh4(rs.getString("ThuocTinh4"));
                entity.setThuocTinh5(rs.getString("ThuocTinh5"));
                entity.setThuocTinh6(rs.getString("ThuocTinh6"));
                entity.setThuocTinh7(rs.getString("ThuocTinh7"));
                entity.setThuocTinh8(rs.getString("ThuocTinh8"));
                entity.setThuocTinh9(rs.getString("ThuocTinh9"));
                entity.setThuocTinh10(rs.getString("ThuocTinh10"));                
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
}
