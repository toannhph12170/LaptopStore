/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.NhanVien;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class NhanVienDAO extends DAdao<NhanVien, String> {

    String INSERT_SQL = "INSERT INTO NhanVien (MaNV, TenNV, MatKhau, VaiTro, NgaySinh, SDT, Hinh) VALUES (?,?,?,?,?,?,?)";
    String UPDATE_SQL = "UPDATE NhanVien SET TenNV =?, MatKhau =?, VaiTro =?, NgaySinh =?, SDT =?, Hinh =? WHERE MaNV = ?";
    String DELETE_SQL = "DELETE FROM NhanVien WHERE MaNV = ?";
    String SELECT_ALL = "SELECT * FROM NhanVien";
    String SELECT_BY_ID = "SELECT * FROM NhanVien WHERE MaNV = ?";
    String DOI_MK = "UPDATE NhanVien SET MatKhau =? WHERE MaNV = ?";

    @Override
    public void insert(NhanVien entity) {
        XJdbc.update(INSERT_SQL, entity.getMaNV(), entity.getTenNV(), entity.getMatKhau(), entity.isVaiTro(),
                entity.getNgaySinh(), entity.getSDT(), entity.getHinh());
    }

    @Override
    public void update(NhanVien entity) {
        XJdbc.update(UPDATE_SQL, entity.getTenNV(), entity.getMatKhau(), entity.isVaiTro(),
                entity.getNgaySinh(), entity.getSDT(), entity.getHinh(), entity.getMaNV());
    }

    @Override
    public void delete(String id) {
        XJdbc.update(DELETE_SQL, id);
    }
    
    public void doimk(NhanVien entity){
        XJdbc.update(DOI_MK, entity.getMatKhau(), entity.getMaNV());
    } 

    @Override
    public List<NhanVien> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public NhanVien selectById(String id) {
        List<NhanVien> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<NhanVien> selectBySql(String sql, Object... args) {
        List<NhanVien> list = new ArrayList<>();
        try {            
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                NhanVien entity = new NhanVien();
                entity.setMaNV(rs.getString("MaNV"));
                entity.setTenNV(rs.getString("TenNV"));
                entity.setMatKhau(rs.getString("MatKhau"));
                entity.setVaiTro(rs.getBoolean("VaiTro"));
                entity.setNgaySinh(rs.getString("NgaySinh"));
                entity.setSDT(rs.getString("SDT"));
                entity.setHinh(rs.getString("Hinh"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public List<NhanVien> selectedByKeyword(String keyword) {
        String sql = "SELECT * FROM NhanVien WHERE TenNV LIKE ?";
        return selectBySql(sql, "%"+keyword+"%");
    }

    

}
