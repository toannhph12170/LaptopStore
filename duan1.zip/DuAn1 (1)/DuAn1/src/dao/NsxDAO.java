/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.NhaSX;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class NsxDAO extends DAdao<NhaSX, String> {

    String INSERT_SQL = "INSERT INTO NhaSX(MaNSX, TenNSX, QuocGia) VALUES(?,?,?)";
    String UPDATE_SQL = "UPDATE NhaSX SET TenNSX =?, QuocGia =? WHERE MaNSX = ?";
    String DELETE_SQL = "DELETE FROM NhaSX WHERE MaNSX = ?";
    String SELECT_ALL = "SELECT * FROM NhaSX";
    String SELECT_BY_ID = "SELECT * FROM NhaSX WHERE MaNSX = ?";

    @Override
    public void insert(NhaSX entity) {
        XJdbc.update(INSERT_SQL, entity.getMaNSX(), entity.getTenNSX(), entity.getQuocGia());
    }

    @Override
    public void update(NhaSX entity) {
        XJdbc.update(UPDATE_SQL, entity.getTenNSX(), entity.getQuocGia(), entity.getMaNSX());
    }

    @Override
    public void delete(String id) {
        XJdbc.update(DELETE_SQL, id);
    }

    @Override
    public List<NhaSX> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public NhaSX selectById(String id) {
        List<NhaSX> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<NhaSX> selectBySql(String sql, Object... args) {
        List<NhaSX> list = new ArrayList<>();
        try {            
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                NhaSX entity = new NhaSX();
                entity.setMaNSX(rs.getString("MaNSX"));
                entity.setTenNSX(rs.getString("TenNSX"));
                entity.setQuocGia(rs.getString("QuocGia"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<NhaSX> selectedByKeyword(String keyword) {
        String sql = "SELECT * FROM NhaSX WHERE TenNSX LIKE ?";
        return selectBySql(sql, "%"+keyword+"%");
    }
    
}
