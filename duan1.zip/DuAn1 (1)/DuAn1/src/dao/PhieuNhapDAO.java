
package dao;

import entity.PhieuNhap;
import helper.Auth;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class PhieuNhapDAO extends DAdao<PhieuNhap, String>{

    String INSERT_SQL = "INSERT INTO PhieuNhap (MaPN, MaNV, MaNCC, NgayNhap) VALUES (?,?,?,?)";
    String UPDATE_SQL = "UPDATE PhieuNhap SET MaNCC =? WHERE MaPN = ?";
    String SELECT_BY_ID = "SELECT * FROM PhieuNhap WHERE MaPN = ?";
    String SELECT_ALL = "SELECT * FROM PhieuNhap";
    String ngayNhap = String.valueOf(java.time.LocalDate.now());

    @Override
    public void insert(PhieuNhap entity) {
        XJdbc.update(INSERT_SQL, entity.getMaPN(), entity.getMaNV(), entity.getMaNCC(), ngayNhap);
    }

    @Override
    public void update(PhieuNhap entity) {
        XJdbc.update(UPDATE_SQL, entity.getMaNCC(), entity.getMaPN());
    }

    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<PhieuNhap> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public PhieuNhap selectById(String id) {
        List<PhieuNhap> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<PhieuNhap> selectBySql(String sql, Object... args) {
        List<PhieuNhap> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.query(sql, args);
            while(rs.next()){
                PhieuNhap entity = new PhieuNhap();
                entity.setMaPN(rs.getString("MaPN"));
                entity.setMaNV(rs.getString("MaNV"));
                entity.setMaNCC(rs.getString("MaNCC"));
                entity.setNgayNhap(rs.getString("NgayNhap"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public List<PhieuNhap> selectedByKeyword(String keyword) {
        String sql = "SELECT * FROM PhieuNhap WHERE MaPN LIKE ?";
        return selectBySql(sql, "%"+keyword+"%");
    }
    
    public List<PhieuNhap> selectedByNCC(String keyword) {
        String sql = "SELECT * FROM PhieuNhap WHERE MaNCC = ?";
        return selectBySql(sql,keyword);
    }
}
