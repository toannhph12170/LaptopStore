package dao;

import entity.BaoHanh;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BaoHanhDAO extends DAdao<BaoHanh, String> {

    String INSERT_BH = "INSERT INTO BaoHanh (MaBH, MaKH, NgayBH) VALUES(?,?,?)";
    String UPDATE_BH = "UPDATE  BaoHanh SET MaKH =?  WHERE MaBH = ?";
    String DELETE_BH = "DELETE FROM BaoHanh WHERE MaBH = ?";
    String SELECT_ALL = "SELECT * from BaoHanh";
    String SELECT_BY_ID = "SELECT * from BaoHanh WHERE MaBH = ?";
    String ngayNhap = String.valueOf(java.time.LocalDate.now());

    @Override
    public void insert(BaoHanh entity) {
        XJdbc.update(INSERT_BH, entity.getMaBH(), entity.getMaKH(), ngayNhap);

    }

    @Override
    public void update(BaoHanh entity) {
        XJdbc.update(UPDATE_BH, entity.getMaKH(), entity.getMaBH());
    }

    @Override
    public void delete(String id) {
        XJdbc.update(DELETE_BH, id);
    }

    @Override
    public List<BaoHanh> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public BaoHanh selectById(String id) {
        List<BaoHanh> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<BaoHanh> selectBySql(String sql, Object... args) {
        List<BaoHanh> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                BaoHanh entity = new BaoHanh();
                entity.setMaBH(rs.getString("MaBH"));
                entity.setMaKH(rs.getString("MaKH"));
                entity.setNgayBH(rs.getString("NgayBH"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<BaoHanh> selectedByKeyword(String keyword) {
        String sql = "SELECT * FROM BaoHanh WHERE MaBH LIKE ?";
        return selectBySql(sql, "%"+keyword+"%");
    }
    
}
