/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.NhaCC;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class NccDAO extends DAdao<NhaCC, String> {

    String INSERT_SQL = "INSERT INTO NhaCC (MaNCC, TenNCC, DiaChi, SDT) VALUES (?,?,?,?)";
    String UPDATE_SQL = "UPDATE NhaCC SET TenNCC =?, DiaChi =?, SDT =? WHERE MaNCC = ?";
    String DELETE_SQL = "DELETE FROM NhaCC WHERE MaNCC = ?";
    String SELECT_ALL = "SELECT * FROM NhaCC";
    String SELECT_BY_ID = "SELECT * FROM NhaCC WHERE MaNCC = ?";

    @Override
    public void insert(NhaCC entity) {
        XJdbc.update(INSERT_SQL, entity.getMaNCC(), entity.getTenNCC(), entity.getDiaChi(), entity.getSDT());
    }

    @Override
    public void update(NhaCC entity) {
        XJdbc.update(UPDATE_SQL, entity.getTenNCC(), entity.getDiaChi(), entity.getSDT(), entity.getMaNCC());
    }

    @Override
    public void delete(String id) {
        XJdbc.update(DELETE_SQL, id);
    }

    @Override
    public List<NhaCC> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public NhaCC selectById(String id) {
        List<NhaCC> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<NhaCC> selectBySql(String sql, Object... args) {
        List<NhaCC> list = new ArrayList<>();
        try {            
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                NhaCC entity = new NhaCC();
                entity.setMaNCC(rs.getString("MaNCC"));
                entity.setTenNCC(rs.getString("TenNCC"));
                entity.setDiaChi(rs.getString("DiaChi"));
                entity.setSDT(rs.getString("SDT"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public List<NhaCC> selectedByKeyword(String keyword) {
        String sql = "SELECT * FROM NhaCC WHERE TenNCC LIKE ? ";
        return selectBySql(sql, "%"+keyword+"%");
    }
    
}
