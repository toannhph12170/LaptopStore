/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.ThietBi;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class ThietBiDAO extends DAdao<ThietBi, String>{

    String INSERT_SQL = "INSERT INTO ThietBi (MaTB, TenTB, MaNSX, MaLoai, GiaNiemYet, MaNCC, HanBaoHanh) "
            + "VALUES (?,?,?,?,?,?,?)";
    String UPDATE_SQL = "UPDATE ThietBi SET TenTB =?, MaNSX =?, MaLoai =?, GiaNiemYet =?, "
            + "Hinh =?, HanBaoHanh =? WHERE MaTB = ?";
    String DELETE_SQL = "DELETE FROM ThietBi WHERE MaTB = ?";
    String SELECT_ALL = "SELECT * FROM ThietBi";
    String SELECT_BY_ID = "SELECT * FROM ThietBi WHERE MaTB = ?";
    
    @Override
    public void insert(ThietBi entity) {
        XJdbc.update(INSERT_SQL, entity.getMaTB(), entity.getTenTB(), entity.getMaNSX(), entity.getMaLoai(),
                entity.getGiaNiemYet(), entity.getMaNCC(), entity.getHanBaoHanh());
    }

    @Override
    public void update(ThietBi entity) {
        XJdbc.update(UPDATE_SQL, entity.getTenTB(), entity.getMaNSX(), entity.getMaLoai(),entity.getGiaNiemYet(),
                entity.getHinh(), entity.getHanBaoHanh(), entity.getMaTB());
    }

    @Override
    public void delete(String id) {
        XJdbc.update(DELETE_SQL, id);
    }

    @Override
    public List<ThietBi> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public ThietBi selectById(String id) {
        List<ThietBi> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<ThietBi> selectBySql(String sql, Object... args) {
        List<ThietBi> list = new ArrayList<>();
        try {            
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                ThietBi entity = new ThietBi();
                entity.setMaTB(rs.getString("MaTB"));
                entity.setTenTB(rs.getString("TenTB"));
                entity.setMaNSX(rs.getString("MaNSX"));
                entity.setMaLoai(rs.getString("MaLoai"));
                entity.setGiaNiemYet(rs.getInt("GiaNiemYet"));
                entity.setMaNCC(rs.getString("MaNCC"));
                entity.setHinh(rs.getString("Hinh"));
                entity.setHanBaoHanh(rs.getInt("HanBaoHanh"));                
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }       
    }
    
    public List<ThietBi> selectedByKeyword(String keyword, String MaLoai) {
        String sql = "SELECT * FROM ThietBi WHERE MaTB LIKE " + "'%" + keyword + "%' and MaLoai = ?";
        return selectBySql(sql, MaLoai);
    }
    
    public List<ThietBi> selectedByMaLoai(String MaLoai) {
        String sql = "SELECT * FROM ThietBi WHERE MaLoai = ?";
        return selectBySql(sql, MaLoai);
    }
}
