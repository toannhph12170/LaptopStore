/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.PhieuXuat;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class PhieuXuatDAO extends DAdao<PhieuXuat, String> {

    String INSERT_SQL = "INSERT INTO PhieuXuat (MaPX, MaNV, MaKH, NgayXuat) VALUES (?,?,?,?)";
    String UPDATE_SQL = "UPDATE PhieuXuat SET MaKH =? WHERE MaPX = ?";
    String SELECT_BY_ID = "select * from PhieuXuat where MaPX = ?";
    String SELECT_ALL = "select *from PhieuXuat";
    String ngayNhap = String.valueOf(java.time.LocalDate.now());

    @Override
    public void insert(PhieuXuat entity) {
        XJdbc.update(INSERT_SQL, entity.getMaPX(), entity.getMaNV(), entity.getMaKH(), ngayNhap);
    }

    @Override
    public void update(PhieuXuat entity) {
        XJdbc.update(UPDATE_SQL, entity.getMaNV(), entity.getMaKH(), ngayNhap, entity.getMaPX());
    }

    @Override
    public void delete(String id) {

    }

    @Override
    public List<PhieuXuat> selectAll() {
        return this.selectBySql(SELECT_ALL);
    }

    @Override
    public PhieuXuat selectById(String id) {
        List<PhieuXuat> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<PhieuXuat> selectBySql(String sql, Object... args) {
        List<PhieuXuat> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                PhieuXuat entity = new PhieuXuat();
                entity.setMaPX(rs.getString("MaPX"));
                entity.setMaNV(rs.getString("MaNV"));
                entity.setMaKH(rs.getString("MaKH"));
                entity.setNgayXuat(rs.getString("NgayXuat"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<PhieuXuat> selectedByKeyword(String keyword) {
        String sql = "select * from PhieuXuat where MaPX like ?";
        return selectBySql(sql, "%" + keyword + "%");
    }

    public List<PhieuXuat> selectedByKH(String keyword) {
        String sql = "select * from PhieuXuat where MaKH = ?";
        return selectBySql(sql,keyword);
    }
}
