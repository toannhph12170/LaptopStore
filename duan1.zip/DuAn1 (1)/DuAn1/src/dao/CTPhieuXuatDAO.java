/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.CTPhieuXuat;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class CTPhieuXuatDAO extends DAdao<CTPhieuXuat, String> {

    String INSERT_SQL = "INSERT INTO ChiTietPX (MaPX, MaTB, SoLuong, DonGiaXuat) VALUES(?,?,?,?)";
    String UPDATE_SQL = "UPDATE ChiTietPX SET SoLuong = ? WHERE MaTB = ? AND MaPX = ?";
    String DELETE_SQL = "DELETE FROM ChiTietPX WHERE MaTB = ? AND MaPX = ?";
    String SELECT_BY_ID = "SELECT * FROM ChiTietPX WHERE MaPX = ?";

    @Override
    public void insert(CTPhieuXuat entity) {
        XJdbc.update(INSERT_SQL, entity.getMaPX(), entity.getMaTB(), entity.getSoLuong(), entity.getDonGia());
    }

    @Override
    public void update(CTPhieuXuat entity) {
        XJdbc.update(UPDATE_SQL, entity.getSoLuong(), entity.getMaTB(), entity.getMaPX());
    }

    public void delete(CTPhieuXuat entity) {
        XJdbc.update(DELETE_SQL, entity.getMaTB(), entity.getMaPX());
    }

    @Override
    public List<CTPhieuXuat> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CTPhieuXuat selectById(String id) {
        List<CTPhieuXuat> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<CTPhieuXuat> selectBySql(String sql, Object... args) {
        List<CTPhieuXuat> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                CTPhieuXuat entity = new CTPhieuXuat();
                entity.setMaPX(rs.getString("MaPX"));
                entity.setMaTB(rs.getString("MaTB"));
                entity.setSoLuong(rs.getInt("SoLuong"));
                entity.setDonGia(rs.getInt("DonGiaXuat"));
                entity.setTongTien(rs.getInt("TongTien"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<CTPhieuXuat> selectedByKeyword(String keyword) {
        String sql = "SELECT *, SoLuong*DonGiaXuat as TongTien FROM ChiTietPX WHERE MaPX = ?";
        return selectBySql(sql, keyword);
    }
}
