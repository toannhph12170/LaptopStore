/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.ThuocTinhTB;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class ThuocTinhTbDAO extends DAdao<ThuocTinhTB, String>{

    String INSERT_SQL = "INSERT INTO ThuocTinhTB(MaTB) VALUES(?)";
    String SELECT_BY_ID = "select * from ThuocTinhTB WHERE MaTB = ?";
    String UPDATE_SQL = "UPDATE ThuocTinhTB SET GiaTri1 =?, GiaTri2 =?, GiaTri3 =?, GiaTri4 =?," +
"GiaTri5 =?, GiaTri6 =?, GiaTri7 =?, GiaTri8 =?, GiaTri9 =?,GiaTri10 =? WHERE MaTB =?";
    
    @Override
    public void insert(ThuocTinhTB entity) {
        XJdbc.update(INSERT_SQL, entity.getMaTB());
    }

    @Override
    public void update(ThuocTinhTB entity) {
        XJdbc.update(UPDATE_SQL, entity.getGiaTri1(), entity.getGiaTri2(), entity.getGiaTri3(), entity.getGiaTri4(),
                 entity.getGiaTri5(), entity.getGiaTri6(), entity.getGiaTri7(), entity.getGiaTri8(), entity.getGiaTri9(),
                  entity.getGiaTri10(), entity.getMaTB());
    }

    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ThuocTinhTB> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ThuocTinhTB selectById(String id) {
        List<ThuocTinhTB> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<ThuocTinhTB> selectBySql(String sql, Object... args) {
        List<ThuocTinhTB> list = new ArrayList<>();
        try {            
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                ThuocTinhTB entity = new ThuocTinhTB();
                entity.setMaTB(rs.getString("MaTB"));
                entity.setGiaTri1(rs.getString("GiaTri1"));
                entity.setGiaTri2(rs.getString("GiaTri2"));
                entity.setGiaTri3(rs.getString("GiaTri3"));
                entity.setGiaTri4(rs.getString("GiaTri4"));
                entity.setGiaTri5(rs.getString("GiaTri5"));
                entity.setGiaTri6(rs.getString("GiaTri6"));
                entity.setGiaTri7(rs.getString("GiaTri7"));
                entity.setGiaTri8(rs.getString("GiaTri8"));
                entity.setGiaTri9(rs.getString("GiaTri9"));
                entity.setGiaTri10(rs.getString("GiaTri10"));                
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
}
