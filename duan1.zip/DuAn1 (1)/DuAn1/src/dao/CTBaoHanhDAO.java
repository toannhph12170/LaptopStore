/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.CTBaoHanh;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class CTBaoHanhDAO extends DAdao<CTBaoHanh, String>{

    String INSERT_CTBH = "INSERT INTO ChiTietBH (MaBH, MaTB, ChiPhi, GhiChu) VALUES (?,?,?,?)";
    String UPDATE_CTBH = "UPDATE ChiTietBH SET MaTB =, ChiPhi =, GhiChu = WHERE MaBH = ?";
    String DELETE_SQL = "delete from ChiTietBH where MaTB = ? and MaBH = ?";
    String SELECT_BY_ID = "select * from ChiTietBH where MaBH = ?";
    @Override
    public void insert(CTBaoHanh entity) {
        XJdbc.update(INSERT_CTBH, entity.getMaBH(), entity.getMaTB(), entity.getChiPhi(), entity.getGhiChu());
    }

    @Override
    public void update(CTBaoHanh entity) {
        XJdbc.update(UPDATE_CTBH, entity.getMaTB(), entity.getChiPhi(), entity.getGhiChu());
    }

    public void delete(CTBaoHanh entity) {
        XJdbc.update(DELETE_SQL, entity.getMaTB(), entity.getMaBH());
    }
    
    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CTBaoHanh> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CTBaoHanh selectById(String id) {
        List<CTBaoHanh> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<CTBaoHanh> selectBySql(String sql, Object... args) {
        List<CTBaoHanh> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                CTBaoHanh entity = new CTBaoHanh();
                entity.setMaBH(rs.getString("MaBH"));
                entity.setMaTB(rs.getString("MaTB"));
                entity.setChiPhi(rs.getInt("ChiPhi"));
                entity.setGhiChu(rs.getString("GhiChu"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public List<CTBaoHanh> selectedByKeyword(String keyword) {
        String sql = "SELECT * FROM ChiTietBH WHERE MaBH = ?";
        return selectBySql(sql,keyword);
    }
}
