/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.CTPhieuNhap;
import helper.XJdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class CTPhieuNhapDAO extends DAdao<CTPhieuNhap, String>{

    String INSERT_SQL = "INSERT INTO ChiTietPN (MaPN, MaTB, SoLuong, DonGiaNhap) VALUES(?,?,?,?)";
    String UPDATE_SQL = "UPDATE ChiTietPN SET SoLuong = ? WHERE MaTB = ? AND MaPN = ?";
    String DELETE_SQL = "DELETE FROM ChiTietPN WHERE MaTB = ? AND MaPN = ?";
    String SELECT_BY_ID = "SELECT * FROM ChiTietPN WHERE MaPN = ?";
    
    @Override
    public void insert(CTPhieuNhap entity) {
        XJdbc.update(INSERT_SQL, entity.getMaPN(), entity.getMaTB(), entity.getSoLuong(), entity.getDonGia());
    }

    @Override
    public void update(CTPhieuNhap entity) {
        XJdbc.update(UPDATE_SQL, entity.getSoLuong(), entity.getMaTB(), entity.getMaPN());
    }

    public void delete(CTPhieuNhap entity) {
        XJdbc.update(DELETE_SQL, entity.getMaTB(), entity.getMaPN());
    }

    @Override
    public List<CTPhieuNhap> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CTPhieuNhap selectById(String id) {
        List<CTPhieuNhap> list = this.selectBySql(SELECT_BY_ID, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<CTPhieuNhap> selectBySql(String sql, Object... args) {
        List<CTPhieuNhap> list = new ArrayList<>();
        try {            
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                CTPhieuNhap entity = new CTPhieuNhap();
                entity.setMaPN(rs.getString("MaPN"));
                entity.setMaTB(rs.getString("MaTB"));
                entity.setSoLuong(rs.getInt("SoLuong"));
                entity.setDonGia(rs.getInt("DonGiaNhap"));
                entity.setTongTien(rs.getInt("TongTien"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<CTPhieuNhap> selectedByKeyword(String keyword) {
        String sql = "SELECT *, SoLuong*DonGiaNhap as TongTien FROM ChiTietPN WHERE MaPN = ?";
        return selectBySql(sql, keyword);
    }
    
}
