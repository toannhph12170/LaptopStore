/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.doanhThu;
import helper.XJdbc;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
public class ThongKeDAO {

    
    protected static doanhThu selectBySql(String sql, Object... args) {
        doanhThu t = new doanhThu();
        try {
            ResultSet rs = XJdbc.query(sql, args);
            while (rs.next()) {
                t.setT(rs.getInt(1));
            }
            rs.getStatement().getConnection().close();
            return t;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static doanhThu selectedDT(int month, int year) {
        String SELECT_SP = "{CALL sp_DoanhThu(?,?)}";
        return selectBySql(SELECT_SP, month, year);
    }
}
